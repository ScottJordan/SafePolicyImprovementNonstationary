for d in */ ; do
        cd $d
        rm allres*.csv
        cat stationary_*.csv >> allres_stationary.csv
        cat nonstationary_*.csv >> allres_nonstationary.csv
        cd ..
done
